import java.util.*;

public class Main {
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);

        
        int[] numbers = new int[10];

        
        System.out.println("Enter 10 integers:");

        for (int i = 0; i < numbers.length; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = input.nextInt();
        }

        int choice;

       
        do {
            System.out.println("\n===== NUMBER MANAGEMENT SYSTEM =====");
            System.out.println("1. Display all numbers");
            System.out.println("2. Count positive numbers");
            System.out.println("3. Find the largest number");
            System.out.println("4. Check even or odd");
            System.out.println("5. Search for a number");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            choice = input.nextInt();

            
            switch (choice) {

                case 1:
                    
                    System.out.println("Numbers in the array:");

                    for (int i = 0; i < numbers.length; i++) {
                        System.out.println(numbers[i]);
                    }
                    break;

                case 2:
                   
                    int i = 0;
                    int positive = 0;

                    while (i < numbers.length) {
                        if (numbers[i] > 0) {
                            positive++;
                        }
                        i++;
                    }

                    System.out.println("Positive numbers: " + positive);
                    break;

                case 3:
                    
                    int largest = numbers[0];

                    for (int j = 1; j < numbers.length; j++) {
                        if (numbers[j] > largest) {
                            largest = numbers[j];
                        }
                    }

                    System.out.println("Largest number: " + largest);
                    break;

                case 4:
                    
                    System.out.print("Enter a number: ");
                    int num = input.nextInt();

                    if (num % 2 == 0) {
                        System.out.println(num + " is even.");
                    } else {
                        System.out.println(num + " is odd.");
                    }
                    break;

                case 5:
                    
                    System.out.print("Enter target number: ");
                    int target = input.nextInt();

                    int index = 0;
                    int frequency = 0;

                    while (index < numbers.length) {
                        if (numbers[index] == target) {
                            frequency++;
                        }
                        index++;
                    }

                    
                    if (frequency > 0) {
                        System.out.println(target + " appears "
                                + frequency + " time(s).");
                    } else {
                        System.out.println("Number does not exist.");
                    }
                    break;

                case 6:
                    System.out.println("Program ended.");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 6);

        input.close();
    }
}