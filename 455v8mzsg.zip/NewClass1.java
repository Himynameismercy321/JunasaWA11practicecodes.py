import java.util.*;

public class Newclass1 {
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);

        int[] numbers = new int[10];

        // Enter 10 integers
        System.out.println("Enter 10 integers:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            numbers[i] = input.nextInt();
        }

        // Enter the target number
        System.out.print("Enter target number: ");
        int target = input.nextInt();

        // Count the frequency
        int frequency = 0;

        for (int i = 0; i < 10; i++) {
            if (numbers[i] == target) {
                frequency++;
            }
        }

        // Display the result
        if (frequency > 0) {
            System.out.println(target + " appears " 
                    + frequency + " time(s) in the array.");
        } else {
            System.out.println(target 
                    + " does not exist in the array.");
        }

        input.close();
    }

}
  

