import java.util.*;

public class NewClass2 {
    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);

        // 1. Ask for the number of students
        System.out.print("Enter number of students: ");
        int n = input.nextInt();
        input.nextLine();

        // 2. Create arrays
        String[] names = new String[n];
        int[] grades = new int[n];

        int sum = 0;
        int passed = 0;
        int failed = 0;

        // 3. Input names and grades
        for (int i = 0; i < n; i++) {
            System.out.print("Enter name: ");
            names[i] = input.nextLine();

            System.out.print("Enter grade: ");
            grades[i] = input.nextInt();
            input.nextLine();

            sum += grades[i];

            // 4. Determine pass or fail
            if (grades[i] >= 75) {
                passed++;
            } else {
                failed++;
            }
        }

        // 5. Find highest and lowest grades
        int highest = grades[0];
        int lowest = grades[0];

        for (int i = 1; i < n; i++) {
            if (grades[i] > highest) {
                highest = grades[i];
            }

            if (grades[i] < lowest) {
                lowest = grades[i];
            }
        }

        // 6. Calculate class average
        double average = (double) sum / n;

        // 7. Display student results
        System.out.println("\n===== STUDENT RESULTS =====");

        for (int i = 0; i < n; i++) {
            if (grades[i] >= 75) {
                System.out.println(names[i] + " - "
                        + grades[i] + " - Passed");
            } else {
                System.out.println(names[i] + " - "
                        + grades[i] + " - Failed");
            }
        }

        // 8. Display summary
        System.out.println("Class Average: " + average);
        System.out.println("Highest Grade: " + highest);
        System.out.println("Lowest Grade: " + lowest);
        System.out.println("Students Passed: " + passed);
        System.out.println("Students Failed: " + failed);

        input.close();
    }
}